//
//  ViewController.swift
//  Calculator
//
//  Created by strivin on 2020/10/24.
//

import UIKit

class ViewController: UIViewController {

    // 变量设置
    @IBOutlet var ShowAreaLabel: UILabel! // 展示区域标签
    
    @IBOutlet var NumButtons: [UIButton]! // 数字按钮
    
    @IBOutlet var OpeButtons: [UIButton]! // 操作符按钮
    
    @IBOutlet var secondButtons: [UIButton]! // 双重界面按钮
    
    @IBOutlet var ACButton: UIButton! // AC/C按钮
    
    var cmodel:CalculateModel = CalculateModel() // 计算模块
    
    var operandStr:String = "0" // 操作数字符串
    {
        didSet{ // 被修改后，格式化修改展示区域标签的文本，同时修改当前操作数
            ShowAreaLabel.text = cmodel.formatNumStr(operandStr)
        }
    }
    
    var memoryStr:String = "0" // 存储数字符串
    
    var cacheStr:String = "0" // 缓存数字符串
    
    var currentDoubleOpeIdx = -1 // 当前双目操作符索引
    
    var currentDoubleOpeClickedjustnow = false // 当前双目操作符是否刚刚被按下
    
    var Mmodel:Bool = false // M 模式
    
    var secondInterFace:Bool = false // 第二界面
    
    var ifRad:Bool = true // 是否为弧度制表示（否为角度制表示）
    
    var ifcanDelete:Bool = true // 可删除
    
    // 常量设置
    let cornerRadius:CGFloat = 15.0 // 圆角角度
    
    // 基础款按钮文本常量
    let ACStr:String = "AC" // AC字符串
    let CStr:String = "C" // C字符串
    let addStr:String = "+" // 加法字符串
    let minusStr:String = "--" //减法字符串
    let multiplyStr:String = "×" // 乘法字符串
    let divideStr:String = "÷" // 除法字符串
    let equalStr:String = "=" // 等号字符串
    let percentStr:String = "%" // 百分之字符串
    let oppositeStr:String = "+/--" // 相反数字符串
    let zeroStr = "0" // 零字符串
    let dotStr = "." // 点字符串
    
    // 科学款按钮文本常量
    // Line1
    let leftBracketStr = "(" // 左括号字符串
    let rightracketStr = ")" // 右括号字符串
    let mcStr = "mc" // mc字符串
    let maddStr = "m+" // m+字符串
    let mminusStr = "m-" // m-字符串
    let mrStr = "mr" // mr字符串
    // Line2
    let secondStr = "2nd" // 2nd字符串
    let x2Str = "x^2" // x^2字符串
    let x3Str = "x^3" // x^3字符串
    let xyStr = "x^y" // x^y字符串
    let expStr = "e^x" // e^x字符串
    let yxStr = "y^x" // y^x字符串(2nd for e^x)
    let tenxStr = "10^x" // 10^x字符串
    let twoxStr = "2^x" // 2^x字符串(2nd for 10^x)
    // Line3
    let x1Str = "1/x" // 1/x字符串
    let sqrtx2Str = "2√x" // 2√x字符串
    let sqrtx3Str = "3√x" // 3√x字符串
    let sqrtxyStr = "y√x" // y√x字符串
    let lnStr = "ln" // ln字符串
    let logyStr = "logy" // logy字符串(2nd for ln)
    let log10Str = "log10" // log10字符串
    let log2Str = "log2" // log2字符串(2nd for log10)
    // Line4
    let factorialStr = "x!" // x!字符串
    let sinStr = "sin" // sin字符串
    let cosStr = "cos" // cos字符串
    let tanStr = "tan" // tan字符串
    let asinStr = "sin-1" // arcsin字符串(2nd for sin)
    let acosStr = "cos-1" // arccos字符串(2nd for cos)
    let atanStr = "tan-1" // arctan字符串(2nd for tan)
    let eStr = "e" // e字符串
    let EEStr = "EE" // EE字符串
    // line5
    let RadStr = "Rad" // 弧度制字符串(turn to Deg)
    let DegStr = "Deg" // 角度制字符串(turn to Rad)
    let sinhStr = "sinh" // sinh字符串
    let coshStr = "cosh" // cosh字符串
    let tanhStr = "tanh" // tanh字符串
    let asinhStr = "sinh-1" // arcsinh字符串(2nd for sinh)
    let acoshStr = "cosh-1" // arccosh字符串(2nd for cosh)
    let atanhStr = "tanh-1" // arctanh字符串(2nd for tanh)
    let piStr = "π" // π字符串
    let RandStr = "Rand" // 随机数字符串
    
    
    
    // 界面初始化方法
    override func viewDidLoad() {
        super.viewDidLoad()
        // 设置圆角
        for b in NumButtons{
            b.layer.cornerRadius = cornerRadius
        }
        for b in OpeButtons{
            b.layer.cornerRadius = cornerRadius
        }
        ACButton.layer.cornerRadius = cornerRadius
        
    }

    // 数字按钮被按，修改操作数字符串
    // 同时相应修改AC/C按钮文本
    // 如果当前双目操作符已存在，则仅还原其颜色，并清空操作数字符串后再修改
    @IBAction func NumButtonsClicked(_ sender: UIButton) {
        // 如果当前双目操作符已存在，说明此时正在设置第二操作数，若刚刚按下双目操作符，则第一次应该清空操作数字符串
        if currentDoubleOpeIdx != -1 && currentDoubleOpeClickedjustnow == true{
            operandStr = zeroStr
            currentDoubleOpeClickedjustnow = false
        }
        
        // 还原当前双目操作符颜色
        switchColor(currentDoubleOpeIdx)
        
        // 修改操作数字符串
        if operandStr == zeroStr{
            if sender.currentTitle == dotStr{ // "0" => "0."
                operandStr += sender.currentTitle!
            }
            else{ // "0" => "N"
                operandStr = sender.currentTitle!
            }
        }
        else{ // "abc" => "abcN"
            operandStr += sender.currentTitle!
        }
        
        // 修改AC/C按钮文本
        if operandStr != zeroStr{
            ACButton.setTitle(CStr, for: .normal)
        }
        else{
            ACButton.setTitle(ACStr, for: .normal)
        }
        
        
    }
    
    // AC按钮被按，清空当前操作数字符串和缓存数字符串，同时还原当前双目操作符颜色和索引
    // C按钮被按，仅清空当操作数字符串，同时AC/C按钮文本设置为AC
    @IBAction func ACButtonClicked(_ sender: UIButton) {
        if sender.currentTitle == ACStr{
            operandStr = zeroStr
            cacheStr = zeroStr
            switchColor(currentDoubleOpeIdx)
            currentDoubleOpeIdx = -1
        }
        else if sender.currentTitle == CStr{
            operandStr = zeroStr
            ACButton.setTitle(ACStr, for: .normal)
        }
    }
    
    // 双目操作符被按，设置当前双目操作符索引，并高亮该双目操作符
    // 设置缓存数字符串为操作数字符串
    @IBAction func DoubleOpeButtonClicked(_ sender: UIButton) {
        // 如果当前操作符已存在，则还原其颜色
        switchColor(currentDoubleOpeIdx)
       // 搜索当前操作符索引
        currentDoubleOpeIdx = findcurrentOpeIdx(sender.currentTitle!)
        // 高亮该双目操作符
        switchColor(currentDoubleOpeIdx)
        // 设置缓存数字符串
        cacheStr = "" + operandStr
        // 设置当前双目操作符刚刚被按下
        currentDoubleOpeClickedjustnow = true
    }
    
    // 单目操作符被按，立即作用于当前操作数
    @IBAction func SingleOpeButtonClicked(_ sender: UIButton) {
        switch sender.currentTitle{
        case percentStr: // 除以100
            operandStr = cmodel.divideToPercent(operandStr)
        case oppositeStr: // 取相反数
            operandStr = cmodel.getOpposite(operandStr)
            
        case secondStr: // 第一/第二界面转化
            turnPage()
        case RadStr: // 弧度制转化为角度制
            turnRadDeg()
        case DegStr: // 角度制转化为弧度制
            turnRadDeg()
            
        case x1Str: // 1/x
            operandStr = cmodel.reciprocal(operandStr)
        case x2Str: // x^2
            operandStr = cmodel.square(operandStr)
        case x3Str: // x^3
            operandStr = cmodel.cube(operandStr)
        case expStr: // e^x
            operandStr = cmodel.myexp(operandStr)
        case yxStr: // y^x(2nd for e^x)
            DoubleOpeButtonClicked(sender) // 此时为双目操作符解释
        case twoxStr: // 2^x(2nd for 10^x)
            operandStr = cmodel.twopow(operandStr)
        case tenxStr: // 10^x
            operandStr = cmodel.tenpow(operandStr)
        case sqrtx2Str: // 2√x
            operandStr = cmodel.mysqrt(operandStr)
        case sqrtx3Str: // 3√x
            operandStr = cmodel.mycuberoot(operandStr)
        case lnStr: // lnx
            operandStr = cmodel.myln(operandStr)
        case logyStr: // logyx
            DoubleOpeButtonClicked(sender) // 此时为双目操作符解释
        case log10Str: // log10x
            operandStr = cmodel.mylog10(operandStr)
        case log2Str: //log2x(2nd for log10x)
            operandStr = cmodel.mylog2(operandStr)
        case factorialStr: // x!
            operandStr = cmodel.myfactorial(operandStr)
            
        case piStr: // π
            operandStr = cmodel.getPI()
            ACButton.setTitle(CStr, for: .normal)  // 相当于按下了一个数字
        case eStr: // e
            operandStr = cmodel.getE()
            ACButton.setTitle(CStr, for: .normal)  // 相当于按下了一个数字
        
        case RandStr: // rand(0,1)
            operandStr = cmodel.Rand()
            
        case mcStr: // mc(清空存储数，并退出M模式)
            memoryStr = "0"
            switchMmodel(false)
        case maddStr: // m+(存储数减去当前操作数，并进入M模式)
            memoryStr = cmodel.add(memoryStr, operandStr)
            switchMmodel(true)
        case mminusStr: // m-(存储数加上将当前操作数，并进入M模式)
            memoryStr = cmodel.minus(memoryStr, operandStr)
            switchMmodel(true)
        case mrStr: // mr(显示当前存储数，并进入M模式)
            operandStr = "" + memoryStr
            switchMmodel(true)
        case sinStr: // sinx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.mysin(tmpStr)
            }
            else{
                operandStr = cmodel.mysin(operandStr)
            }
        case cosStr: // cosx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.mycos(tmpStr)
            }
            else{
                operandStr = cmodel.mycos(operandStr)
            }
        case tanStr: // tanx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.mytan(tmpStr)
            }
            else{
                operandStr = cmodel.mytan(operandStr)
            }
        case sinhStr: // sinhx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.mysinh(tmpStr)
            }
            else{
                operandStr = cmodel.mysinh(operandStr)
            }
        case coshStr: // coshx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.mycosh(tmpStr)
            }
            else{
                operandStr = cmodel.mycosh(operandStr)
            }
        case tanhStr: // tanhx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.mytanh(tmpStr)
            }
            else{
                operandStr = cmodel.mytanh(operandStr)
            }
        case asinStr: // asinx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.myasin(tmpStr)
            }
            else{
                operandStr = cmodel.myasin(operandStr)
            }
        case acosStr: // acosx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.myacos(tmpStr)
            }
            else{
                operandStr = cmodel.myacos(operandStr)
            }
        case atanStr: // atanx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.myatan(tmpStr)
            }
            else{
                operandStr = cmodel.myatan(operandStr)
            }
        case asinhStr: // asinhx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.myasinh(tmpStr)
            }
            else{
                operandStr = cmodel.myasinh(operandStr)
            }
        case acoshStr: // acoshx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.myacosh(tmpStr)
            }
            else{
                operandStr = cmodel.myacosh(operandStr)
            }
        case atanhStr: // atanhx
            if ifRad == false{ //角度制则先转化成弧度制
                let tmpStr = cmodel.degToRad(operandStr)
                operandStr = cmodel.myatanh(tmpStr)
            }
            else{
                operandStr = cmodel.myatanh(operandStr)
            }
        default: break
            
        }
    }
    
    // 等于操作符被按
    // 如果当前双目操作符存在，
    // 普通模式下，用缓存数和当前操作数进行当前双目操作符对应的运算，并置缓存数为当前操作数
    // M模式下，用存储数和当前操作数进行当前双目操作符对应的运算，并置缓存数为当前操作数
    // 如果不存在，则默认将当前操作数和缓存数进行加法运算，但不改变缓存数
    @IBAction func EqualOpeButtonClicked(_ sender: UIButton) {
        if currentDoubleOpeIdx != -1{
            // 第一个操作数设置
            var tmpNumStr = ""
            if Mmodel == false{ // 普通模式
                tmpNumStr += cacheStr
            }
            else{ // M模式
                tmpNumStr += memoryStr
            }
            
            // 设置缓存数为当前操作数
            cacheStr = "" + operandStr
            
            // 选择并执行双目操作
            switch OpeButtons[currentDoubleOpeIdx].currentTitle{
            case addStr: // 加法
                operandStr = cmodel.add(tmpNumStr, operandStr)
            case minusStr: // 减法
                operandStr = cmodel.minus(tmpNumStr, operandStr)
            case multiplyStr: // 乘法
                operandStr = cmodel.multiply(tmpNumStr, operandStr)
            case divideStr: // 除法(除数为零则报错，除非AC/C消除)
                operandStr = cmodel.divide(tmpNumStr, operandStr)
            case xyStr: // x^y
                operandStr = cmodel.mypow(tmpNumStr, operandStr)
            case yxStr: // y^x
                operandStr = cmodel.ypow(tmpNumStr, operandStr)
            case sqrtxyStr: // y√x
                operandStr = cmodel.yroot(tmpNumStr, operandStr)
            case logyStr: // logyx
                operandStr = cmodel.mylogy(tmpNumStr, operandStr)
            case EEStr: // EE(x*10^y)
                operandStr = cmodel.EE(tmpNumStr, operandStr)
            default:break
            }
            
            // 还原当前双目操作符索引
            currentDoubleOpeIdx = -1
        }
        else{
            operandStr = cmodel.add(cacheStr, operandStr)
        }
    }
    
    
    // 展示区域标签中左滑右滑，可以逐个依次删除当前操作数字符串
    @IBAction func handlePaninShowAreaLabel(_ gesture:UIPanGestureRecognizer){
        let translation = gesture.translation(in: view)
        if (translation.x > 10 || translation.x < -10) && ifcanDelete == true {
            var tmpStr = ""
            for (idx,c) in operandStr.enumerated(){
                if idx != operandStr.count-1{
                    tmpStr += String(c)
                }
            }
            operandStr = "" + tmpStr
            if operandStr == ""{
                operandStr = zeroStr
            }
            ifcanDelete = false
        }
        gesture.setTranslation(.zero, in: view)
        if gesture.state == .ended{
            ifcanDelete = true
        }
    }
    
    
    // 交换当前操作符按钮的背景颜色和文本颜色
    func switchColor(_ idx:Int){
        if idx != -1{
            let titleColor = OpeButtons[idx].currentTitleColor
            let backgroundColor = OpeButtons[idx].backgroundColor
            OpeButtons[idx].setTitleColor(backgroundColor, for: .normal)
            OpeButtons[idx].backgroundColor = titleColor
        }
    }
    
    // 寻找当前操作符索引
    func findcurrentOpeIdx(_ currentTitle:String)->Int{
        var resIdx = -1
        for (idx,b) in OpeButtons.enumerated(){
            if b.currentTitle == currentTitle{
                resIdx = idx
                break
            }
        }
        return resIdx
    }
    
    // 科学计算器第一/第二界面转化
    func turnPage(){
        // 转化界面
        secondInterFace = !secondInterFace
        // 交换颜色
        let idx = findcurrentOpeIdx(secondStr)
        switchColor(idx)
        // 交换按钮文本
        for (idx,b) in secondButtons.enumerated(){
            if secondInterFace == false{ // 转化成第一界面
                switch b.currentTitle{
                case yxStr: // y^x => e^x
                    secondButtons[idx].setTitle(expStr, for: .normal)
                case twoxStr: // 2^x => 10^x
                    secondButtons[idx].setTitle(tenxStr, for: .normal)
                case logyStr: // logy => 1n
                    secondButtons[idx].setTitle(lnStr, for: .normal)
                case log2Str: // log2 => 1og10
                    secondButtons[idx].setTitle(log10Str, for: .normal)
                case asinStr: // asin => sin
                    secondButtons[idx].setTitle(sinStr, for: .normal)
                case acosStr: // acos => cos
                    secondButtons[idx].setTitle(cosStr, for: .normal)
                case atanStr: // atan => tan
                    secondButtons[idx].setTitle(tanStr, for: .normal)
                case asinhStr: // asinh => sinh
                    secondButtons[idx].setTitle(sinhStr, for: .normal)
                case acoshStr: // acosh => cosh
                    secondButtons[idx].setTitle(coshStr, for: .normal)
                case atanhStr: // atanh => tanh
                    secondButtons[idx].setTitle(tanhStr, for: .normal)
                default:break
            }
            }
            else{ // 转化成第二界面
                switch b.currentTitle{
                case expStr: // e^x => y^x
                    secondButtons[idx].setTitle(yxStr, for: .normal)
                case tenxStr: // 10^x => 2^x
                    secondButtons[idx].setTitle(twoxStr, for: .normal)
                case lnStr: // ln => 1ogy
                    secondButtons[idx].setTitle(logyStr, for: .normal)
                case log10Str: // log10 => 1og2
                    secondButtons[idx].setTitle(log2Str, for: .normal)
                case sinStr: // sin => asin
                    secondButtons[idx].setTitle(asinStr, for: .normal)
                case cosStr: // cos => acos
                    secondButtons[idx].setTitle(acosStr, for: .normal)
                case tanStr: // tan => atan
                    secondButtons[idx].setTitle(atanStr, for: .normal)
                case sinhStr: // sinh => asinh
                    secondButtons[idx].setTitle(asinhStr, for: .normal)
                case coshStr: // cosh => acosh
                    secondButtons[idx].setTitle(acoshStr, for: .normal)
                case tanhStr: // tanh => atanh
                    secondButtons[idx].setTitle(atanhStr, for: .normal)
                default:break
            }
    }
    }
}
    
    // 角度制弧度制转化
    func turnRadDeg()
    {
        ifRad = !ifRad
        if ifRad == true{ // 转化为弧度制
            let rdIdx = findcurrentOpeIdx(DegStr)
            OpeButtons[rdIdx].setTitle(RadStr, for: .normal)
        }
        else{ // 转化为角度制
            let rdIdx = findcurrentOpeIdx(RadStr)
            OpeButtons[rdIdx].setTitle(DegStr, for: .normal)
        }
    }
    
    // switchM模式
    func switchMmodel(_ to:Bool){
        if Mmodel != to{
            let idx = findcurrentOpeIdx(mrStr)
            switchColor(idx)
        }
        Mmodel = to
    }

}
