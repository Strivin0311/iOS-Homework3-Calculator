//
//  CalculateModel.swift
//  Calculator
//
//  Created by strivin on 2020/10/24.
//

import Foundation

class CalculateModel{
    
    
    let ERROR:String = "ERROR" // 错误字符串(对错误字符串进行操作，无论如何结果都是错误)
    
    let PI:String = "3.1415926535897932" // π
    let E:String = "2.71828182845904523" // e
    
    // 格式化数字字符串
    func formatNumStr(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var resNumStr = oriNumStr // 整数部分/最终字符串
        var decNumStr = "" // 小数部分字符串
        var negativeSign = "" // 负号
        
        // 预处理数字字符串
        for (idx,c) in resNumStr.enumerated(){
            if c == "-" && idx == 0{ // 预处理：负号单独提出，保证resNumStr为正
                negativeSign = "-"
                resNumStr = removeNegative(resNumStr)
            }
            if c == "."{ // 预处理：如果有小数，则分开整数部分和小数部分
                (resNumStr,decNumStr) = separate(resNumStr)
                break
            }
        }
        
        // 添加逗号
        if resNumStr.count > 3{ // 如果整数部分数字位数超过3，则每3个数字之间相隔一个逗号
            var insertIdx = resNumStr.index(resNumStr.endIndex, offsetBy:-3)// 初始插入下标
            while insertIdx > resNumStr.startIndex{
                resNumStr.insert(",", at:insertIdx)
                if insertIdx >= resNumStr.index(resNumStr.startIndex, offsetBy:3){
                    insertIdx = resNumStr.index(insertIdx, offsetBy:-3)// 更新插入下标
                }
                else{
                    break
                }
            }
        }
        
        resNumStr += decNumStr // 拼接小数部分
        return negativeSign + resNumStr // 拼接负号
    }
    
    // 分离数字字符串的整数部分和小数部分
    func separate(_ oriNumStr:String)->(String,String){
        if oriNumStr == ERROR{
            return (ERROR,"")
        }
        var intNumStr = "" // 整数部分
        var decNumStr = "" // 小数部分
        let NumStrArr = oriNumStr.split(separator: ".")
        if NumStrArr.count == 1{ // 如果仅有小数点而小数部分未定义，则小数部分字符串为“.”
            intNumStr = String(NumStrArr[0])
            decNumStr = "."
        }
        else{ // 否则分别设置整数部分和小数部分
            intNumStr = String(NumStrArr[0])
            decNumStr = "."+String(NumStrArr[1])
        }
        
        return (intNumStr,decNumStr)
    }
    
    // 去掉数字字符串前的负号
    func removeNegative(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        let NumStrArr = oriNumStr.split(separator: "-")
        let resNumStr = String(NumStrArr[0])
        return resNumStr
    }
    
    // 求得数字字符串的百分数形式
    func divideToPercent(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!  // 因为精度问题，此处转化为Float类型便于展示
        oriNum /= 100.0
        let resNumStr = FloatToString(oriNum)

        return resNumStr
    }
    
    // 求得数字字符串的相反数形式
    func getOpposite(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        let oriNum = -Float(oriNumStr)!
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // 将Double类型转化为数字字符串（没有小数则截取整数部分）
    func DoubleToString(_ oriNum:Double)->String{
        var resNumStr = ""
        let decimal = oriNum - Double(Int(oriNum))
        if decimal == 0.0{
            resNumStr = String(Int(oriNum))
        }
        else{
            resNumStr = String(oriNum)
        }
        return resNumStr
    }
    
    // 将Float类型转化为数字字符串（没有小数则截取整数部分）
    func FloatToString(_ oriNum:Float)->String{
        var resNumStr = ""
        let decimal = oriNum - Float(Int(oriNum))
        if decimal == 0.0{
            resNumStr = String(Int(oriNum))
        }
        else{
            resNumStr = String(oriNum)
        }
        return resNumStr
    }
    
    // 加法
    func add(_ oriNumStr1:String, _ oriNumStr2:String)->String{
        if oriNumStr1 == ERROR || oriNumStr2 == ERROR {
            return ERROR
        }
        let num1 = Float(oriNumStr1)!
        let num2 = Float(oriNumStr2)!
        let resNum = num1 + num2
        let resNumStr = FloatToString(resNum)
        
        return resNumStr
    }
    
    // 减法
    func minus(_ oriNumStr1:String, _ oriNumStr2:String)->String{
        if oriNumStr1 == ERROR || oriNumStr2 == ERROR {
            return ERROR
        }
        let num1 = Float(oriNumStr1)!
        let num2 = Float(oriNumStr2)!
        let resNum = num1 - num2
        let resNumStr = FloatToString(resNum)
        
        return resNumStr
    }
    
    // 乘法
    func multiply(_ oriNumStr1:String, _ oriNumStr2:String)->String{
        if oriNumStr1 == ERROR || oriNumStr2 == ERROR {
            return ERROR
        }
        let num1 = Float(oriNumStr1)!
        let num2 = Float(oriNumStr2)!
        let resNum = num1 * num2
        let resNumStr = FloatToString(resNum)
        
        return resNumStr
    }
    
    // 除法(除数为零，则返回错误)
    func divide(_ oriNumStr1:String, _ oriNumStr2:String)->String{
        if oriNumStr1 == ERROR || oriNumStr2 == ERROR {
            return ERROR
        }
        let num1 = Float(oriNumStr1)!
        let num2 = Float(oriNumStr2)!
        var resNumStr = ""
        
        if num2 == 0.0{
            resNumStr = "ERROR"
        }
        else{
            let resNum = num1 / num2
            resNumStr = FloatToString(resNum)
        }
        
        return resNumStr
    }
    
    // x^2
    func square(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = oriNum * oriNum
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // x^3
    func cube(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = oriNum * oriNum * oriNum
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // x^y
    func mypow(_ oriNumStr:String,_ yStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        let yNum = Float(yStr)!
        oriNum = pow(oriNum,yNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // e^x
    func myexp(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = exp(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // 10^x
    func tenpow(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = pow(10,oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // 2^x
    func twopow(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = pow(2,oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // y^x
    func ypow(_ oriNumStr:String,_ yStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        let yNum = Float(yStr)!
        var oriNum = Float(oriNumStr)!
        oriNum = pow(yNum,oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // 1/x (分母为零，则返回错误)
    func reciprocal(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        if oriNum == 0.0{
            return ERROR
        }
        oriNum = pow(oriNum,-1)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // 2√x
    func mysqrt(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        if oriNum < 0.0{
            return ERROR
        }
        oriNum = sqrt(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // 3√x
    func mycuberoot(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = pow(oriNum,1.0/3.0)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // y√x
    func yroot(_ oriNumStr:String,_ yStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        let yNum = Float(yStr)!
        if yNum == 0.0{
            return ERROR
        }
        if oriNum < 0.0{  // 此处不限制定义域，直接绝对值开方，之后取原始符号
            oriNum = -pow(-oriNum,1.0/yNum)
        }
        else{
            oriNum = pow(oriNum,1.0/yNum)
        }
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // lnx
    func myln(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        if oriNum < 0.0{
            return ERROR
        }
        oriNum = log(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // log10x
    func mylog10(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        if oriNum < 0.0{
            return ERROR
        }
        oriNum = log10(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // log2x
    func mylog2(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        if oriNum < 0.0{
            return ERROR
        }
        oriNum = log2(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // logyx
    func mylogy(_ oriNumStr:String, _ yStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        let yNum = Float(yStr)!
        if oriNum < 0.0 || yNum < 0.0 || yNum == 1.0{
            return ERROR
        }
        oriNum = log(oriNum) / log(yNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // x!
    func myfactorial(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        let oriNum = Float(oriNumStr)!
        var intNum = 0
        var resNum = 1
        let decimal = oriNum - Float(Int(oriNum))
        if decimal == 0.0{
            intNum = Int(oriNum)
        }
        else{
            return ERROR
        }
        if intNum < 0{
            intNum = -intNum
            for i in 1...intNum{
                resNum *= i
            }
            resNum = -resNum
        }
        else if intNum > 0{
            for i in 1...intNum{
                resNum *= i
            }
        }
        
        let resNumStr = String(resNum)
        
        return resNumStr
    }
    
    // sin
    func mysin(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = sin(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // cos
    func mycos(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = cos(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // tan
    func mytan(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        let k:Float = oriNum / (Float(PI)!/2)
        let decimal = k - Float(Int(k))
        if abs(decimal) < 0.000001{ // π/2的倍数，tan无穷
            return ERROR
        }
        oriNum = tan(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // arcsin
    func myasin(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        if oriNum > 1.0 || oriNum < 1.0{
            return ERROR
        }
        oriNum = asin(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // arccos
    func myacos(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        if oriNum > 1.0 || oriNum < 1.0{
            return ERROR
        }
        oriNum = acos(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // arctan
    func myatan(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = atan(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // sinh
    func mysinh(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = sinh(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // cosh
    func mycosh(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = cosh(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // tanh
    func mytanh(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        if oriNum == 0.0{
            return ERROR
        }
        oriNum = tanh(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // arcsinh
    func myasinh(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        oriNum = asinh(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // arccosh
    func myacosh(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        if oriNum < 1.0{
            return ERROR
        }
        oriNum = acosh(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // arctanh
    func myatanh(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        if oriNum >= 1.0 || oriNum <= 1.0{
            return ERROR
        }
        oriNum = atanh(oriNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // EE(x*10^y)
    func EE(_ oriNumStr:String, _ yStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        var oriNum = Float(oriNumStr)!
        let yNum = Float(yStr)!
        oriNum = oriNum * pow(10,yNum)
        let resNumStr = FloatToString(oriNum)
        
        return resNumStr
    }
    
    // Rand(产生(0,1)的随机数字符串)
    func Rand()->String{
        let randNum = Float(arc4random()) / Float(UInt32.max)
        let resNumStr = String(randNum)
        return resNumStr
    }
    
    // 弧度制转化为角度制
    func radToDeg(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        let radNum = Float(oriNumStr)!
        let degNum = (radNum / Float(PI)!) * 180.0
        let resNumStr = FloatToString(degNum)
        
        return resNumStr
    }
    
    // 角度制转化为弧度制
    func degToRad(_ oriNumStr:String)->String{
        if oriNumStr == ERROR{
            return ERROR
        }
        let degNum = Float(oriNumStr)!
        let radNum = (degNum / 180.0) * Float(PI)!
        let resNumStr = FloatToString(radNum)
        
        return resNumStr
    }
    
    // E
    func getE()->String{
        return E
    }
    
    // PI
    func getPI()->String{
        return PI
    }
    
    
}
